#' an alternative to table which gives a summary of totals
#'
#' @author Craig Marsh
#' @export
#'
evalit = function(x) {eval(parse(text = x))}

